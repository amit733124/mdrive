<html>
<title>No Access File...</title>
<body>
	<center><font color="red"><h1>Forbidden</h1></font><br>You don't have permission to access/image/on tis server.</center>
	</body>
	</html> 